#ifndef ADD_H
#define ADD_H
 
// This is the content of the .h file, which is where the declarations go


double euclideandistance(int x1,int y1,int x2,int y2);

double cityblockdistance(int x1,int y1,int x2,int y2);



#endif
