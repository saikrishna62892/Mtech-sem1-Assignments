awk -f awkscript.awk cricket.csv
